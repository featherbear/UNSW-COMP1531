class Order:
    def __init__(self, id, qty):
        self.id = id
        self.qty = qty

